<?php
/**
 * ГНБ-Эксперт - Статический сервер для Next.js на PHP хостинге
 * Этот файл обслуживает статический контент Next.js приложения
 */

// Настройки
ini_set('display_errors', 0);
error_reporting(0);

// Получаем URI запроса
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);

// Удаляем слеши в начале и конце
$path = trim($path, '/');

// Если путь пустой - это главная страница
if (empty($path)) {
    $path = 'index';
}

// Функция для отправки статического файла
function serveStaticFile($file) {
    if (!file_exists($file)) {
        return false;
    }
    
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    $mime_types = [
        'css' => 'text/css',
        'js' => 'application/javascript',
        'json' => 'application/json',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'ico' => 'image/x-icon',
        'woff' => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf' => 'font/ttf',
        'eot' => 'application/vnd.ms-fontobject'
    ];
    
    if (isset($mime_types[$ext])) {
        header('Content-Type: ' . $mime_types[$ext]);
        header('Cache-Control: public, max-age=31536000'); // 1 год
    }
    
    readfile($file);
    return true;
}

// Обработка статических ресурсов Next.js
if (strpos($path, '_next/static/') === 0) {
    $static_file = './' . $path;
    if (serveStaticFile($static_file)) {
        exit;
    }
}

// Обработка изображений из папки public
if (strpos($path, 'images/') === 0) {
    $image_file = './public/' . $path;
    if (serveStaticFile($image_file)) {
        exit;
    }
}

// Обработка favicon и других файлов из public
$public_files = ['favicon.ico', 'robots.txt', 'sitemap.xml', 'manifest.json'];
if (in_array($path, $public_files)) {
    $public_file = './public/' . $path;
    if (serveStaticFile($public_file)) {
        exit;
    }
}

// Маршрутизация для страниц
$routes = [
    'index' => '.next/server/app/page.html',
    '' => '.next/server/app/page.html',
    'articles' => '.next/server/app/articles/page.html',
    'admin' => '.next/server/app/admin/page.html'
];

// Обработка динамических маршрутов статей
if (preg_match('/^articles\/([^\/]+)$/', $path, $matches)) {
    $slug = $matches[1];
    $article_file = ".next/server/app/articles/{$slug}/page.html";
    if (file_exists($article_file)) {
        include $article_file;
        exit;
    }
}

// Обработка основных маршрутов
if (isset($routes[$path])) {
    $html_file = $routes[$path];
    if (file_exists($html_file)) {
        header('Content-Type: text/html; charset=UTF-8');
        include $html_file;
        exit;
    }
}

// Fallback на главную страницу для неизвестных маршрутов (SPA behavior)
if (file_exists('.next/server/app/page.html')) {
    header('Content-Type: text/html; charset=UTF-8');
    include '.next/server/app/page.html';
} else {
    // Простая заглушка если нет файлов
    header('HTTP/1.0 404 Not Found');
    echo '<!DOCTYPE html>
<html>
<head>
    <title>ГНБ-Эксперт - Сайт недоступен</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>ГНБ-Эксперт</h1>
    <p>Сайт временно недоступен. Пожалуйста, попробуйте позже.</p>
    <p>Телефон: +7 (XXX) XXX-XX-XX</p>
</body>
</html>';
}
?> 